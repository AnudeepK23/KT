# identity-password-validation

This micro-service enables consumer to get identity password length and validate partial password.