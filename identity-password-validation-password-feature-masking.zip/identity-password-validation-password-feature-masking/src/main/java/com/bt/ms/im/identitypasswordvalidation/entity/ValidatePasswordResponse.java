package com.bt.ms.im.identitypasswordvalidation.entity;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ValidatePasswordResponse extends BaseResponse {

	private ValidatePassword password;

}
