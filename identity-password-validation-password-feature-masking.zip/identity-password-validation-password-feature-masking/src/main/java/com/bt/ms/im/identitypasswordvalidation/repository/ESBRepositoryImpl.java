package com.bt.ms.im.identitypasswordvalidation.repository;


import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import com.bt.ms.im.identitypasswordvalidation.annotation.ClientInfo;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;

@Repository
public  class ESBRepositoryImpl implements ESBRepository {

	@Autowired
	RestTemplate msRestTemplate;

	@Value("${queryCustomerForValidation.url}")
	String queryCustomerForValidationUrl;
	
	
	@Value("${validationpasswordUrl.url}")
	String validationpasswordUrl;

	@Autowired
	AppConstants appConstants;

	@ClientInfo(clientSystem = "ESB", compTxnName = "queryCustomerForValidation")
	public ResponseBean<CustomerValidationResponse> queryCustomerForValidation(GetPasswordLengthRequest request) {

		String queryCustomerForValidation = queryCustomerForValidationUrl;
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<Object> requestEntity = new HttpEntity<>(null, headers);
		
		ResponseEntity<CustomerValidationResponse> response = msRestTemplate.exchange(
				queryCustomerForValidation.replace("{customerId}", request.getCustId()), HttpMethod.GET,
				requestEntity, CustomerValidationResponse.class);
		
		// Backend exception handling
		if (ObjectUtils.isEmpty(response)) {
			return ResponseBean.errorRes(CustomerValidationResponse.class, this.appConstants.getErrorRes().getClientErrorCode(),
					this.appConstants.getErrorRes().getMessage());
		}
		return ResponseBean.of(response.getBody());
	}

	@ClientInfo(clientSystem = "ESB", compTxnName = "validatepassword")
	public ResponseBean<ValidateCustomerPassword> validatePassword(ValidatePasswordRequest request) {
		
		String validatepwdUrl = validationpasswordUrl;
		
		validatepwdUrl = validatepwdUrl.replace("{customerId}", request.getCustId());
		validatepwdUrl = validatepwdUrl.replace("{char1}", request.getChar1());
		validatepwdUrl = validatepwdUrl.replace("{char2}", request.getChar2());
		validatepwdUrl = validatepwdUrl.replace("{position1}", request.getPosition1());
		validatepwdUrl = validatepwdUrl.replace("{position2}", request.getPosition2());
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<Object> requestEntity = new HttpEntity<>(null, headers);
		
		ResponseEntity<ValidateCustomerPassword> response = msRestTemplate.exchange(
				validatepwdUrl, HttpMethod.GET,
				requestEntity, ValidateCustomerPassword.class);

		// Backend exception handling
		if (ObjectUtils.isEmpty(response)) {
			return ResponseBean.errorRes(ValidateCustomerPassword.class, this.appConstants.getErrorRes().getClientErrorCode(),
					this.appConstants.getErrorRes().getMessage());
		}
		return ResponseBean.of(response.getBody());
	}

}