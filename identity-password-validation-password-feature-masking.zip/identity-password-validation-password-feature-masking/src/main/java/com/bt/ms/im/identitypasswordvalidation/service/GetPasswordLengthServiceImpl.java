package com.bt.ms.im.identitypasswordvalidation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.mapper.GetPasswordLengthResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepository;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepository;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;

@Service
public class GetPasswordLengthServiceImpl implements GetPasswordLengthService {

	@Autowired
	GetPasswordLengthResponseMapper mapper;

	@Autowired
	AppConstants appConstants;

	@Autowired
	private ESBRepository esbrepo;

	@Autowired
	private ExcaliburRepository excrepo;

	@Override
	public ResponseBean<GetPasswordLengthResponse> getPasswordLength(GetPasswordLengthRequest request) {

		ResponseBean<CustomerValidationResponse> customervalidationres = null;
		ResponseBean<GetSubscriberAuthenticationDetailsResponse> customerValidationRes = null;
		GetPasswordLengthResponse passwordres = new GetPasswordLengthResponse();
		String brand = request.getBrand();
		String type = request.getType();

		// call to ESB
		if (appConstants.getIdentityPasswordValidation().getBtcBrand().equals(brand)
				&& appConstants.getIdentityPasswordValidation().getBtcType().equals(type)) {

			customervalidationres = esbrepo.queryCustomerForValidation(request);
			passwordres = mapper.mapperEsb(customervalidationres);
		}

		// call to BTSEL
		if (appConstants.getIdentityPasswordValidation().getEeBrand().equals(brand)
				&& appConstants.getIdentityPasswordValidation().getEeGETType().equals(type)) {
			customerValidationRes = excrepo.getSubscriberAuthenticationDetails(request);
			passwordres = mapper.mapperExcalibur(customerValidationRes);
		}

		return ResponseBean.of(passwordres);
	}
}