package com.bt.ms.im.identitypasswordvalidation.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.ms.im.identitypasswordvalidation.annotation.ClientInfo;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.mapper.ValidateEERequestMapper;
import com.bt.ms.im.identitypasswordvalidation.util.ExcaliburGetSubscriberUtil;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.ExcaliburValidatePasswordClient;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordRequest;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.ExcaliburGetSubscriberAuthenticationDetailsClient;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.EIMessageContext2;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsRequest;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;

@Repository
public class ExcaliburRepositoryImpl implements ExcaliburRepository {

	@Autowired
	ExcaliburGetSubscriberAuthenticationDetailsClient excaliburGetSubscriberAuthenticationDetailsClient;

	@Autowired
	ValidateEERequestMapper validateEERequestMapper;

	@Autowired
	ExcaliburValidatePasswordClient excaliburValidatePasswordClient;
	
	@Autowired
	ExcaliburGetSubscriberUtil util;

	@ClientInfo(clientSystem = "excalibur", compTxnName = "GetSubscriber")
	public ResponseBean<GetSubscriberAuthenticationDetailsResponse> getSubscriberAuthenticationDetails(
			GetPasswordLengthRequest request) {

		GetSubscriberAuthenticationDetailsRequest getSubscriberAuthenticationDetailsRequest = new GetSubscriberAuthenticationDetailsRequest();
		EIMessageContext2 eiMessageContext2 = new EIMessageContext2();
		eiMessageContext2.setSender("BTSEL");
		eiMessageContext2.setCorrelationId(request.getTrackingHeader());

		getSubscriberAuthenticationDetailsRequest.setEiMessageContext2(eiMessageContext2);
		GetSubscriberAuthenticationDetailsRequest.Message message = new GetSubscriberAuthenticationDetailsRequest.Message();
		
		if (request.getCustId().startsWith("07")  && !request.getCustId().startsWith("070") && !request.getCustId().startsWith("076")) {
			
			String msisdn = util.convertmsisdn(request.getCustId());
			message.setMsisdn(msisdn);
		}
		else {

			message.setMsisdn(request.getCustId());
		}

		getSubscriberAuthenticationDetailsRequest.setMessage(message);

		GetSubscriberAuthenticationDetailsResponse response = excaliburGetSubscriberAuthenticationDetailsClient
				.getsubscriber(getSubscriberAuthenticationDetailsRequest);
		return ResponseBean.of(response);
	}

	@ClientInfo(clientSystem = "excalibur", compTxnName = "Validationpassword")
	public ResponseBean<ValidateAuthenticationPasswordResponse> validateAuthenticationPassword(ValidatePasswordRequest request) {


		ValidateAuthenticationPasswordRequest validateAuthenticationPasswordRequest = validateEERequestMapper
				.validateBTCRequest(request);

		ValidateAuthenticationPasswordResponse response = excaliburValidatePasswordClient
				.Validationpassword(validateAuthenticationPasswordRequest);
		return ResponseBean.of(response);
	}

}
