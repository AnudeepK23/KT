package com.bt.ms.im.identitypasswordvalidation.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.service.SpringApplicationContextHolder;

/*
 * @param <T>
 * 
 * @author Suman Mandal
 */
@ToString
@Getter
@Setter
public class ResponseBean<T> {
	private T data;
	  private ResponseStatus status;
	  private String code;
	  private String message;
	  private List<RootExceptionDetails> rootExceptions;
	  private HttpStatus statusCode;

	  public enum ResponseStatus {
	    SUCCESS,
	    FAILURE,
	    PER_FAIL
	  }

	  public ResponseBean() {}

	  public ResponseBean(T data) {
	    super();
	    this.data = data;
	  }

	  /**
	   * This method will create a success response and . set the data there
	   *
	   * @param t
	   * @return
	   */
	  public static <T> ResponseBean<T> of(T t) {
	    ResponseBean<T> rb = new ResponseBean<T>(t);
	    rb.setStatus(ResponseStatus.SUCCESS);
	    return rb;
	  }

	  /**
	   * This method will return error response
	   *
	   * @param t
	   * @return
	   */
	  public static <T> ResponseBean<T> errorRes(Class<?> T, ResponseBean<?> resBean) {
	    ResponseBean<T> rb = new ResponseBean<>();
	    rb.setStatus(resBean.getStatus());
	    rb.setCode(resBean.getCode());
	    rb.setMessage(resBean.getMessage());
	    rb.setRootException(resBean.getRootExceptions());
	    return rb;
	  }

	  public static ResponseBean<?> errorRes() {
	    return errorRes(
	        getAppConstant().getErrorRes().getClientErrorCode(),
	        getAppConstant().getErrorRes().getMessage());
	  }

	  public static <T> ResponseBean<T> errorRes(Class<?> T) {
	    return errorRes(
	        T,
	        getAppConstant().getErrorRes().getClientErrorCode(),
	        getAppConstant().getErrorRes().getMessage());
	  }

	  public static ResponseBean<?> errorRes(String code, String message) {
	    ResponseBean<?> rb = new ResponseBean<>();
	    rb.setStatus(ResponseStatus.FAILURE);
	    rb.setCode(code);
	    rb.setMessage(message);
	    return rb;
	  }

	  public static <T> ResponseBean<T> errorRes(Class<?> T, String code, String message) {
	    ResponseBean<T> rb = new ResponseBean<>();
	    rb.setStatus(ResponseStatus.FAILURE);
	    rb.setCode(code);
	    rb.setMessage(message);
	    return rb;
	  }

	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  public static ResponseBean errorRes(String code, String message, RootExceptionDetails rootException) {
			ResponseBean rb = new ResponseBean();
			rb.setStatus(ResponseStatus.FAILURE);
			rb.setCode(code);
			rb.setMessage(message);
			if (rootException != null) {
				List<RootExceptionDetails> list = new ArrayList<>();
				list.add(rootException);
				rb.setRootException(list);
			}
			return rb;
		}
	  
	  public static <T> ResponseBean<T> errorRes(
	      Class<?> T, String code, String message, RootExceptionDetails rootException) {
	    ResponseBean<T> rb = new ResponseBean<>();
	    rb.setStatus(ResponseStatus.FAILURE);
	    rb.setCode(code);
	    rb.setMessage(message);
	    if (rootException != null) {
	      List<RootExceptionDetails> list = new ArrayList<>();
	      list.add(rootException);
	      rb.setRootException(list);
	    }
	    return rb;
	  }

	  public static <T> ResponseBean<T> errorRes(
	      Class<?> T, String code, String message, List<RootExceptionDetails> rootExceptionList) {
	    ResponseBean<T> rb = new ResponseBean<>();
	    rb.setStatus(ResponseStatus.FAILURE);
	    rb.setCode(code);
	    rb.setMessage(message);
	    rb.setRootException(rootExceptionList);
	    return rb;
	  }
	  
	  
	  public static <T> ResponseBean<T> errorRes(
		      @SuppressWarnings("rawtypes") Class T,
		      String code,
		      String message,
		      HttpStatus statusCode) {
		    ResponseBean<T> rb = new ResponseBean<>();
		    rb.setStatus(ResponseStatus.FAILURE);
		    rb.setCode(code);
		    rb.setMessage(message);
		    rb.setStatusCode(statusCode);
		    return rb;
		  }

	  public boolean isFailed() {
	    if (ResponseStatus.FAILURE.equals(this.status)) {
	      return true;
	    }
	    return false;
	  }

	  public boolean isSuccess() {
	    if (ResponseStatus.SUCCESS.equals(this.status)) {
	      return true;
	    }
	    return false;
	  }

	  public boolean isPertialfail() {
	    if (ResponseStatus.PER_FAIL.equals(this.status)) {
	      return true;
	    }
	    return false;
	  }
	  /** @return the data */
	  public T getData() {
	    return data;
	  }
	  /** @param data the data to set */
	  public void setData(T data) {
	    this.data = data;
	  }
	  /** @return the status */
	  public ResponseStatus getStatus() {
	    return status;
	  }
	  /** @param status the status to set */
	  public void setStatus(ResponseStatus status) {
	    this.status = status;
	  }
	  /** @return the code */
	  public String getCode() {
	    return code;
	  }
	  /** @param code the code to set */
	  public void setCode(String code) {
	    this.code = code;
	  }
	  /** @return the message */
	  public String getMessage() {
	    return message;
	  }
	  /** @param message the message to set */
	  public void setMessage(String message) {
	    this.message = message;
	  }
	  /** @return the rootException */
	  public List<RootExceptionDetails> getRootExceptions() {
	    return rootExceptions;
	  }
	  /** @param rootException the rootException to set */
	  public void setRootException(List<RootExceptionDetails> rootExceptions) {
	    this.rootExceptions = rootExceptions;
	  }

	  public static AppConstants getAppConstant() {
	    return SpringApplicationContextHolder.getBean(AppConstants.class);
	  }

	  public void appendRootException(List<RootExceptionDetails> list) {
	    if (list != null && list.size() > 0) {
	      List<RootExceptionDetails> rootExceptionDetails = this.getRootExceptions();
	      if (rootExceptionDetails == null) rootExceptionDetails = new ArrayList<>();
	      this.setRootException(rootExceptionDetails);
	      if (this.isSuccess()) {
	        this.setStatus(ResponseStatus.PER_FAIL);
	      }
	      rootExceptionDetails.addAll(list);
	    }
	  }

	  public void appendRootException(
	      List<RootExceptionDetails> list, List<RootExceptionDetails> list1) {
	    appendRootException(list, list1, null, null);
	  }

	  public void appendRootException(
	      List<RootExceptionDetails> list,
	      List<RootExceptionDetails> list1,
	      List<RootExceptionDetails> list2) {
	    appendRootException(list, list1, list2, null);
	  }

	  public void appendRootException(
	      List<RootExceptionDetails> list,
	      List<RootExceptionDetails> list1,
	      List<RootExceptionDetails> list2,
	      List<RootExceptionDetails> list3) {
	    List<RootExceptionDetails> rootExceptionDetails = this.getRootExceptions();
	    if (rootExceptionDetails == null) rootExceptionDetails = new ArrayList<>();
	    boolean hasRe = false;
	    if (list != null && list.size() > 0) {
	      hasRe = true;
	      if (this.isSuccess()) {
	        this.setStatus(ResponseStatus.PER_FAIL);
	      }
	      rootExceptionDetails.addAll(list);
	    }
	    if (list1 != null && list1.size() > 0) {
	      hasRe = true;
	      if (this.isSuccess()) {
	        this.setStatus(ResponseStatus.PER_FAIL);
	      }
	      rootExceptionDetails.addAll(list1);
	    }
	    if (list2 != null && list2.size() > 0) {
	      hasRe = true;
	      if (this.isSuccess()) {
	        this.setStatus(ResponseStatus.PER_FAIL);
	      }
	      rootExceptionDetails.addAll(list2);
	    }
	    if (list3 != null && list3.size() > 0) {
	      hasRe = true;
	      if (this.isSuccess()) {
	        this.setStatus(ResponseStatus.PER_FAIL);
	      }
	      rootExceptionDetails.addAll(list3);
	    }
	    if (hasRe) this.setRootException(rootExceptionDetails);
	  }
	}
