package com.bt.ms.im.identitypasswordvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.bt.ms.im", "com.ee.ms.im"})
public class IdentityValidationApplication {

  public static void main(String[] args) {

    SpringApplication.run(IdentityValidationApplication.class, args);
  }
}
