package com.bt.ms.im.identitypasswordvalidation.service;


import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;

public interface GetPasswordLengthService {

	ResponseBean<GetPasswordLengthResponse> getPasswordLength(GetPasswordLengthRequest request);

}
