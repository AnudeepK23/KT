package com.bt.ms.im.identitypasswordvalidation.repository;

import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;


public interface ESBRepository {
	
	ResponseBean<CustomerValidationResponse> queryCustomerForValidation(GetPasswordLengthRequest request);
	ResponseBean<ValidateCustomerPassword> validatePassword(ValidatePasswordRequest request);
	
}
