package com.bt.ms.im.identitypasswordvalidation.util;

import java.util.List;

import org.springframework.stereotype.Component;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.RootExceptionDetails;


@Component
public class EsbGetSubscriberUtil {
	
	private AppConstants appConstants;
	
	@SuppressWarnings("unchecked")
	public ResponseBean<GetPasswordLengthResponse> handleDownstreamError(String reasonCode, String reasonText,
			List<String> errorDetails, String downstreamComponent) {
		if (reasonText != null && errorDetails != null) {
			return ResponseBean.errorRes(errorDetails.get(0), errorDetails.get(1),
					RootExceptionDetails.of(downstreamComponent, reasonCode, reasonText));
		} else {
			return handleUnknownError(downstreamComponent);
		}
	}

	@SuppressWarnings("unchecked")
	public ResponseBean<GetPasswordLengthResponse> handleUnknownError(String downstreamComponent) {
		return ResponseBean.errorRes(this.appConstants.getErrorRes().getClientErrorCode(),
				this.appConstants.getErrorRes().getMessage(),
				RootExceptionDetails.of(downstreamComponent, this.appConstants.getErrorRes().getClientUnavErrorCode(),
						this.appConstants.getErrorRes().getTempUnavMessage()));
	}
	
	
	}


