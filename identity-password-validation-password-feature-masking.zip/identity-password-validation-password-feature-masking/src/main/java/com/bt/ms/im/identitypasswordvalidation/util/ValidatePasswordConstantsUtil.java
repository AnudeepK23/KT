package com.bt.ms.im.identitypasswordvalidation.util;

public class ValidatePasswordConstantsUtil {
	
	public static final String QUERY_PARAM = "?";
	  public static final String AMPERCENT = "&";
	  public static final String EQUALS = "=";
	  public static final String SLASH = "/";

	  public static final String PASSWORD = "password.xml";
	  public static final String CHAR1 = "char1";
	  public static final String CHAR2 = "char2";
	  public static final String POSITION1 = "position1";
	   public static final String POSITION2 = "position2";
	  public static final String STACK = "STACK";
	   public static final String CCP = "CCP";
	   
	  private ValidatePasswordConstantsUtil() {
	    throw new IllegalStateException("Utility class");
	  }

}
