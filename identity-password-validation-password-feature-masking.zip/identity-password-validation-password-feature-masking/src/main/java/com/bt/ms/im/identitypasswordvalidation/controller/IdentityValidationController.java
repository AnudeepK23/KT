package com.bt.ms.im.identitypasswordvalidation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.BaseResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;
import com.bt.ms.im.identitypasswordvalidation.service.GetPasswordLengthService;
import com.bt.ms.im.identitypasswordvalidation.service.ValidatePasswordStatusService;
import com.bt.ms.im.identitypasswordvalidation.util.RequestValidator;

@RestController
@RequestMapping("/common/v1/identity-password-validation")
@EnableAutoConfiguration
public class IdentityValidationController {

	@Autowired
	RequestValidator requestValidator;

	@Autowired
	AppConstants appConstants;

	@Autowired
	private GetPasswordLengthService identityvalidationservice;

	@Autowired
	private ValidatePasswordStatusService validatePasswordService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping(value = "/password", produces = { "application/json" })
	public ResponseEntity<GetPasswordLengthResponse> getPasswordLength(
			@RequestParam(value = "id", required = true) String custId,
			@RequestParam(value = "brand", required = true) String brand,
			@RequestParam(value = "type", required = true) String type,
			@RequestHeader(value = "APIGW-Tracking-Header", required = false) String apigwTrackingHeader,
			@RequestHeader(value = "E2EDATA", required = false) String e2eData,
			@RequestHeader(value = "accept", required = true) String acceptHeader) {

		GetPasswordLengthRequest getPassLengthrequest = new GetPasswordLengthRequest();
		getPassLengthrequest.setCustId(custId);
		getPassLengthrequest.setType(type);
		getPassLengthrequest.setTrackingHeader(apigwTrackingHeader);
		getPassLengthrequest.setE2eData(e2eData);
		getPassLengthrequest.setAcceptHeader(acceptHeader);
		getPassLengthrequest.setBrand(brand);
		
		requestValidator.validateGetPasswordLengthRequest(getPassLengthrequest);

		ResponseBean<GetPasswordLengthResponse> response = identityvalidationservice
				.getPasswordLength(getPassLengthrequest);
		if (response.isSuccess()) {
			return new ResponseEntity<>(response.getData(), HttpStatus.OK);
		}

		else {
			BaseResponse errorRes = new BaseResponse();
			errorRes.setCode(response.getCode());
			errorRes.setMessage(response.getMessage());
			errorRes.setRootException(response.getRootExceptions());
			HttpStatus status = setGetPasswordLengthErrorRes(response);
			
			return new ResponseEntity(errorRes, status);
		}
	}
		private HttpStatus setGetPasswordLengthErrorRes(ResponseBean<GetPasswordLengthResponse> resp) {
			HttpStatus status = null;
			if (resp.getCode().equals(this.appConstants.getErrorRes().getClientErrorCode())) {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			} else if (resp.getCode().equals(this.appConstants.getErrorRes().getClientUnavErrorCode())) {
				status = HttpStatus.SERVICE_UNAVAILABLE;
			} else if (resp.getCode().equals(this.appConstants.getErrorRes().getValidationfailedErrorCode())) {
				status = HttpStatus.BAD_REQUEST;
			} else if (resp.getCode().equals(this.appConstants.getErrorRes().getClientNotFoundErrorCode())) {
				status = HttpStatus.NOT_FOUND;
			} else {
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
			return status;
		}
		

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PutMapping(value = "/password")
	public ResponseEntity<ValidatePasswordResponse> validatePasswordStatus(
			@RequestParam(value = "id", required = true) String custId,
			@RequestParam(value = "brand", required = true) String brand,
			@RequestParam(value = "type", required = true) String type,
			@RequestBody @Valid ValidatePasswordRequest validatePasswordRequest,
			@RequestHeader(value = "APIGW-Tracking-Header", required = false) String apigwTrackingHeader,
			@RequestHeader(value = "E2EDATA", required = false) String e2eData,
			@RequestHeader(value = "accept", required = true) String acceptHeader) {

		// POST with Body supplied
		/* Set request values in request parameter */
		validatePasswordRequest.setBrand(brand);
		validatePasswordRequest.setType(type);
		validatePasswordRequest.setCustId(custId);
		validatePasswordRequest.setTrackingHeader(apigwTrackingHeader);
		validatePasswordRequest.setE2eData(e2eData);
		// To Validate the request

		requestValidator.validateValidatePasswordRequest(validatePasswordRequest);

		ResponseBean<ValidatePasswordResponse> response = validatePasswordService
				.validatePasswordStatus(validatePasswordRequest);
		if (response.isSuccess()) {
			return new ResponseEntity<>(response.getData(), HttpStatus.OK);
		} else {
			BaseResponse res = new BaseResponse();
			res.setCode(response.getCode());
			res.setMessage(response.getMessage());
			res.setRootException(response.getRootExceptions());
			HttpStatus status = setValidatePasswordErrorRes(response);
			return new ResponseEntity(res, status);
		}
	}
	
	private HttpStatus setValidatePasswordErrorRes(ResponseBean<ValidatePasswordResponse> response) {
		HttpStatus status = null;
		if (response.getCode().equals(this.appConstants.getErrorRes().getClientErrorCode())) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		} else if (response.getCode().equals(this.appConstants.getErrorRes().getClientUnavErrorCode())) {
			status = HttpStatus.SERVICE_UNAVAILABLE;
		} else if (response.getCode().equals(this.appConstants.getErrorRes().getValidationfailedErrorCode())) {
			status = HttpStatus.BAD_REQUEST;
		} else if (response.getCode().equals(this.appConstants.getErrorRes().getClientNotFoundErrorCode())) {
			status = HttpStatus.NOT_FOUND;
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return status;
	}


}
