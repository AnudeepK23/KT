package com.bt.ms.im.identitypasswordvalidation.util;

import java.util.List;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.RootExceptionDetails;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;



public class EsbValidatePasswordUtil {
	
private AppConstants appConstants;
	
	@SuppressWarnings("unchecked")
	public ResponseBean<ValidatePasswordResponse> handleDownstreamError(String reasonCode, String reasonText,
			List<String> errorDetails, String downstreamComponent) {
		if (reasonText != null && errorDetails != null) {
			return ResponseBean.errorRes(errorDetails.get(0), errorDetails.get(1),
					RootExceptionDetails.of(downstreamComponent, reasonCode, reasonText));
		} else {
			return handleUnknownError(downstreamComponent);
		}
	}

	@SuppressWarnings("unchecked")
	public ResponseBean<ValidatePasswordResponse> handleUnknownError(String downstreamComponent) {
		return ResponseBean.errorRes(this.appConstants.getErrorRes().getClientErrorCode(),
				this.appConstants.getErrorRes().getMessage(),
				RootExceptionDetails.of(downstreamComponent, this.appConstants.getErrorRes().getClientUnavErrorCode(),
						this.appConstants.getErrorRes().getTempUnavMessage()));
	}

}
