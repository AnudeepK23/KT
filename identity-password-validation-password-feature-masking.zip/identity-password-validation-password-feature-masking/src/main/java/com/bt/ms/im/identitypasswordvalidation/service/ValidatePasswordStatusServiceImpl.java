package com.bt.ms.im.identitypasswordvalidation.service;

import org.springframework.stereotype.Service;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;
import com.bt.ms.im.identitypasswordvalidation.mapper.ValidatePasswordResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepository;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepository;
import com.bt.ms.im.identitypasswordvalidation.util.ExcaliburValidatePasswordUtil;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ValidatePasswordStatusServiceImpl implements ValidatePasswordStatusService {

	@Autowired
	AppConstants appConstants;

	@Autowired
	ExcaliburValidatePasswordUtil excaliburValidatePasswordUtil;

	@Autowired
	private ESBRepository esbrepo;

	@Autowired
	ValidatePasswordResponseMapper mapper;

	@Autowired
	private ExcaliburRepository excrepo;

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override

	public ResponseBean<ValidatePasswordResponse> validatePasswordStatus(ValidatePasswordRequest request) {

		ValidatePasswordResponse validateRes = new ValidatePasswordResponse();

		/*BTC flow which calls ESB */
		String brand = request.getBrand();
		String type = request.getType();
		
		if(appConstants.getIdentityPasswordValidation().getBtcBrand().equals(brand) && appConstants.getIdentityPasswordValidation().getBtcType().equals(type)) {
			
			ResponseBean<ValidateCustomerPassword> validatePasswordBTCRes = esbrepo.validatePassword(request);
			
			if (validatePasswordBTCRes.isSuccess()) {
				ValidateCustomerPassword validatepasswordresdata = validatePasswordBTCRes.getData();
				validateRes = mapper.mapperEsb(validatepasswordresdata);
			} else if (validatePasswordBTCRes.isFailed()) {
				return ResponseBean.errorRes(ValidateCustomerPassword.class, validatePasswordBTCRes);
			}

		}

		/*EE flow which calls BTSEL Soap Service*/
		if(appConstants.getIdentityPasswordValidation().getEeBrand().equals(brand) && appConstants.getIdentityPasswordValidation().getEePUTType().equals(type)) {
			
			ResponseBean<ValidateAuthenticationPasswordResponse> validationPasswordEERes = excrepo
					.validateAuthenticationPassword(request);
			
			  
            if(validationPasswordEERes.isSuccess())
			{
            	ValidateAuthenticationPasswordResponse validatepasswordresdata=validationPasswordEERes.getData();
				validateRes=mapper.mapperExcalibur(validatepasswordresdata);
				
			}
            else if (validationPasswordEERes.isFailed()) {
				if (validationPasswordEERes.getRootExceptions() != null
						&& validationPasswordEERes.getRootExceptions().get(0) != null
						&& validationPasswordEERes.getRootExceptions().get(0).getReasonCode() != null) {
					String reasonCode = validationPasswordEERes.getRootExceptions().get(0).getReasonCode();
					String reasonText = validationPasswordEERes.getRootExceptions().get(0).getReasonText();
					@SuppressWarnings("unchecked")
					List<String> errorDetails = this.appConstants.getAccount().get(reasonCode);
					if(reasonText.contains(appConstants.getValidateCustomerPassword().getFailureErrorText()))
					{
						validateRes=mapper.mapperExcaliburFailure();	
					}
					else
					{
					return excaliburValidatePasswordUtil.handleDownstreamError(reasonCode, reasonText, errorDetails, "BTSEL-EXC");
					}
				}
				else
				{
					return excaliburValidatePasswordUtil.handleUnknownError("BTSEL-EXC");
			
				}
			}
		}
		
		return ResponseBean.of(validateRes);
	}

}
