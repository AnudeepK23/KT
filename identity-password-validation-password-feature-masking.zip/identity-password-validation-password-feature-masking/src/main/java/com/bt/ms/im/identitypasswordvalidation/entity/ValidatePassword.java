package com.bt.ms.im.identitypasswordvalidation.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidatePassword {
	
	protected String status;

}
