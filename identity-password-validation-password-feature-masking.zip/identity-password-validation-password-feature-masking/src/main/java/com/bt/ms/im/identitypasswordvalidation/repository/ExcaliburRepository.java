package com.bt.ms.im.identitypasswordvalidation.repository;

import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;

public interface ExcaliburRepository {
	
	ResponseBean<GetSubscriberAuthenticationDetailsResponse> getSubscriberAuthenticationDetails(GetPasswordLengthRequest request);

	ResponseBean<ValidateAuthenticationPasswordResponse> validateAuthenticationPassword(ValidatePasswordRequest request);
}
