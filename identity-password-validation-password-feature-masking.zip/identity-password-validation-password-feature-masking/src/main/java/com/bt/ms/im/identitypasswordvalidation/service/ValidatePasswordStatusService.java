package com.bt.ms.im.identitypasswordvalidation.service;


import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;

public interface ValidatePasswordStatusService {

	
	ResponseBean<ValidatePasswordResponse> validatePasswordStatus(ValidatePasswordRequest request);
}
