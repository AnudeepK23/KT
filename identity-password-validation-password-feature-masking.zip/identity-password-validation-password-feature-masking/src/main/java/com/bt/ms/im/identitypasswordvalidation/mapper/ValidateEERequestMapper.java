package com.bt.ms.im.identitypasswordvalidation.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordRequest;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordRequest.Message.PasswordDetails;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordRequest.Message.PasswordDetails.PasswordDetail;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.EIMessageContext2;

@Component
public class ValidateEERequestMapper {

	@Autowired
	AppConstants appConstants;

	// Request Construction for BTSEL
	public ValidateAuthenticationPasswordRequest validateBTCRequest(ValidatePasswordRequest request) {

		ValidateAuthenticationPasswordRequest validateAuthenticationPasswordRequest = new ValidateAuthenticationPasswordRequest();

		EIMessageContext2 eiMessageContext2 = new EIMessageContext2();

		eiMessageContext2.setSender(appConstants.getIdentityPasswordValidation().getSender());
		eiMessageContext2.setCorrelationId(request.getTrackingHeader());

		validateAuthenticationPasswordRequest.setEiMessageContext2(eiMessageContext2);

		ValidateAuthenticationPasswordRequest.Message message = new ValidateAuthenticationPasswordRequest.Message();
		message.setAccountNumber(request.getCustId());

		message.setPasswordCategory(appConstants.getIdentityPasswordValidation().getPasswordcategory());
		PasswordDetails passwordDetails = new PasswordDetails();

		PasswordDetail passwordDetail1 = new PasswordDetail();
		PasswordDetail passwordDetail2 = new PasswordDetail();

        List<PasswordDetail> passwordDetailList = new ArrayList<>();
		
		passwordDetail1.setCharacterPosition(request.getPosition1());

		passwordDetail1.setCharacterValue(request.getChar1());
		
		passwordDetailList.add(passwordDetail1);
		
		passwordDetail2.setCharacterPosition(request.getPosition2());

		passwordDetail2.setCharacterValue(request.getChar2());
		
		passwordDetailList.add(passwordDetail2);
		
		passwordDetails.getPasswordDetail().addAll(passwordDetailList);

		message.setPasswordDetails(passwordDetails);

		validateAuthenticationPasswordRequest.setMessage(message);

		return validateAuthenticationPasswordRequest;
	}
}
