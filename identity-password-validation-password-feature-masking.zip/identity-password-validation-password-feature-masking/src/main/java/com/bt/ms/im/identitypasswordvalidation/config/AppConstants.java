/** */
package com.bt.ms.im.identitypasswordvalidation.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

/**
 * Application wise constant , will fetch the value from constants.properties
 * file
 *
 */
@Configuration
@PropertySource("classpath:constants.properties")
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class AppConstants {

	
	
	private Pattern pattern;
	private Header header;
	private ErrorRes errorRes; 
	private IdentityPasswordValidation identityPasswordValidation;
	private ValidateCustomerPassword validateCustomerPassword;

	
	
	@Getter
	@Setter
	public static class ErrorRes {
		private String message;
		private String internalErrorCode;
		private String clientErrorCode;
		private String validationfailedErrorCode;
		private String clientUnavErrorCode;
		private String clientNotFoundErrorCode;
		private String tempUnavMessage;

	}


	@Getter
	@Setter
	public static class Header {
		private String accept;
		private String trackingHeader;
		private String channel;
		private String channelValue;
	}


	@Getter
	@Setter
	public static class Pattern {
		private String trackingid;
		private String msisdn;
	}
	
	@Getter
	@Setter
	public static class QueryCustomerForValidation{
		private String path;
		private String customerId;
	}
	
	@Getter
	@Setter
	public static class IdentityPasswordValidation{
		
		private List<String> brand;
		private List<String> type;
		
		private String eeBrand;
		private String eeGETType;
		private String eePUTType;
		
		private String btcBrand;
		private String btcType;
		
		private String sender;
		
		private String passwordcategory;
		
		private Map<String, List<String>> serviceIdType;
		
	}
	
	@Getter
	@Setter
	public static class ValidateCustomerPassword{
		
		private String successStatus;
		private String failureStatus;
		private String successReturnStatus;
		private String failurReturnStatus;
		private String failureErrorText;
	}
	
	@SuppressWarnings("rawtypes")
	private Map<String, List> subscriber = new HashMap<>();
	
	@SuppressWarnings("rawtypes")
	private Map<String, List> account = new HashMap<>();
	
	@SuppressWarnings("rawtypes")
	private Map<String, List> getesberror = new HashMap<>();

}
