package com.bt.ms.im.identitypasswordvalidation.mapper;

import org.springframework.stereotype.Component;

import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.Password;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;

@Component
public class GetPasswordLengthResponseMapper {

	// BTC flow mapping
	public GetPasswordLengthResponse mapperEsb(ResponseBean<CustomerValidationResponse> customervalidationres) {

		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		Password password = new Password();
		if (customervalidationres.isSuccess()) {
			CustomerValidationResponse customervalidationRes = customervalidationres.getData();
			if (customervalidationRes.getCustomer() != null) {

				CustomerValidationResponse.Customer res = customervalidationRes.getCustomer();
				GetPasswordLengthResponse passwordlength = new GetPasswordLengthResponse();

				if (null != customervalidationRes.getCustomer().getPasswordLength()) {
					password.setPasswordLength(res.getPasswordLength().toString());
				}
				passwordlength.setPassword(password);
				return passwordlength;

			}
		}
		else {
			getPasswordLengthResponse.setPassword(password);
			return getPasswordLengthResponse;
		}
		return getPasswordLengthResponse;

	}

	// EE flow mapping
	public GetPasswordLengthResponse mapperExcalibur(
			ResponseBean<GetSubscriberAuthenticationDetailsResponse> customerValidationRes) {

		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		Password password = new Password();
		if (customerValidationRes.isSuccess()) {
			GetSubscriberAuthenticationDetailsResponse customerValidation = customerValidationRes.getData();
			if (customerValidation.getMessage() != null) {

				GetSubscriberAuthenticationDetailsResponse.Message res = customerValidation.getMessage();
				GetPasswordLengthResponse passwordlength = new GetPasswordLengthResponse();
				if (null != customerValidation.getMessage().getPasswordLength()) {
					password.setPasswordLength(res.getPasswordLength());
				}

				if ( null != customerValidation.getMessage().getPasswordHint()) {
					password.setPasswordHint(res.getPasswordHint());
				}

				passwordlength.setPassword(password);
				return passwordlength;
			}
		} else {
			getPasswordLengthResponse.setPassword(password);
			return getPasswordLengthResponse;
		}
		return getPasswordLengthResponse;
	}

}
