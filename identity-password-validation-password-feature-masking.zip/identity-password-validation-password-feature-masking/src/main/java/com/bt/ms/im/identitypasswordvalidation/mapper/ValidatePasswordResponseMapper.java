package com.bt.ms.im.identitypasswordvalidation.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePassword;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;

@Component
public class ValidatePasswordResponseMapper {

	@Autowired
	AppConstants appConstants;

	public ValidatePasswordResponse mapperEsb(ValidateCustomerPassword validatepasswordresdata) {

		ValidatePasswordResponse passwordStatusRes = new ValidatePasswordResponse();

		ValidatePassword password = new ValidatePassword();

		if (validatepasswordresdata.getStatus().equals(appConstants.getValidateCustomerPassword().getSuccessStatus())) {

			password.setStatus(appConstants.getValidateCustomerPassword().getSuccessReturnStatus());
			passwordStatusRes.setPassword(password);
		} else if (validatepasswordresdata.getStatus()
				.equals(appConstants.getValidateCustomerPassword().getFailureStatus())) {
			password.setStatus(appConstants.getValidateCustomerPassword().getFailurReturnStatus());
			passwordStatusRes.setPassword(password);
		}

		return passwordStatusRes;
	}

	public ValidatePasswordResponse mapperExcalibur(ValidateAuthenticationPasswordResponse validatepasswordresdata) {

		ValidatePasswordResponse passwordStatusRes = new ValidatePasswordResponse();

		ValidatePassword password = new ValidatePassword();

		if (validatepasswordresdata.getMessage().isEmpty()) {

			password.setStatus(appConstants.getValidateCustomerPassword().getSuccessReturnStatus());
			passwordStatusRes.setPassword(password);
		} 
		
		
		
		return passwordStatusRes;
	}
	
	public ValidatePasswordResponse mapperExcaliburFailure() {

		ValidatePasswordResponse passwordStatusRes = new ValidatePasswordResponse();

		ValidatePassword password = new ValidatePassword();

			password.setStatus(appConstants.getValidateCustomerPassword().getFailurReturnStatus());
			passwordStatusRes.setPassword(password);
		return passwordStatusRes;
	}
	
}
