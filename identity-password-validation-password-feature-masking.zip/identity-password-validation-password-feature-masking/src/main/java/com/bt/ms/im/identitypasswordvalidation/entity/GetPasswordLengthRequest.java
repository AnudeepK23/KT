/**
 * 
 */
package com.bt.ms.im.identitypasswordvalidation.entity;

import lombok.Getter;
import lombok.Setter;

/**
 * @author megha_nagaraja
 *
 */

@Getter
@Setter
public class GetPasswordLengthRequest {

	private String trackingHeader;
	private String e2eData;
	private String custId;
	private String acceptHeader;
	private String brand;
	private String type;
}
