package com.bt.ms.im.identitypasswordvalidation.util;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import com.bt.ms.im.identitypasswordvalidation.bptm.BptmContextHolder;
import com.bt.util.logging.E2ETransaction;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * logging the 2981,2984
 * 
 * @author Suman Mandal
 * 
 */
@Component
public class LoggingRequestInterceptor extends HandlerInterceptorAdapter {
	
	@Autowired
	LogUtil logUtil;
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Value("${spring.application.name}")
	private String appName;
	public static final String E2EDATA_HEADER = "E2EDATA";
	private static ObjectMapper objectMapper;

	static {
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse res, Object handler) throws Exception {
		String url = request.getRequestURI();
		String e2edata = null;
		if (url.contains("/password")) {

			StringBuilder sb = new StringBuilder();
			sb.append("2981 uri = ");
			sb.append(request.getRequestURI());
			sb.append("?");
			sb.append(request.getQueryString());
			sb.append(" Method= ");
			sb.append(request.getMethod());

			sb.append(" RequestHeaders=");
			Enumeration<String> headerNames = request.getHeaderNames();
			while (headerNames.hasMoreElements()) {
				String headerName = headerNames.nextElement();
				sb.append(headerName);
				sb.append("=");
				sb.append(request.getHeader(headerName));
				sb.append(" ");
				if (E2EDATA_HEADER.equalsIgnoreCase(headerName)) {
					e2edata = request.getHeader(headerName);
				}
			}

			sb.append("payload=");
			sb.append(getPayload(request));
			String[] urlArr = url.split("/common/v1");
			String serviceName = url;
			if (urlArr.length > 1) {
				String[] splitArr = urlArr[1].split("/");
				serviceName = splitArr[2];
			}
			
			if (e2edata != null) {
				BptmContextHolder.createContext(serviceName + "-" + request.getMethod(), appName, e2edata);
			} else {
				BptmContextHolder.createContext(serviceName + "-" + request.getMethod(), appName);
			}
			E2ETransaction e2eTxn = BptmContextHolder.getE2ETxn();
			e2eTxn.startInboundCall();
			String finalLog = logUtil.maskLog(sb.toString());
			e2eTxn.logMessage("2981", finalLog);
			log.info(finalLog);
		}
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse responseWrapper, Object handler,
			@Nullable Exception ex) throws Exception {
		String url = request.getRequestURI();
		if (url.contains("/password")) {
			E2ETransaction e2eTxn = BptmContextHolder.getE2ETxn();
			responseWrapper.addHeader(E2EDATA_HEADER, e2eTxn.toString());
			StringBuilder sb = new StringBuilder();
			sb.append("2984  Status Code :: ");
			sb.append(responseWrapper.getStatus());
			sb.append(System.lineSeparator());
			sb.append(" ResponseHeaders :: ");
			for (String headerName : responseWrapper.getHeaderNames()) {
				sb.append(headerName);
				sb.append("=");
				sb.append(responseWrapper.getHeader(headerName));
				sb.append(" ");
			}
			sb.append(System.lineSeparator());
			String payLoad = getPayload(responseWrapper);
			if (payLoad != null) {

				sb.append(" Body :: ");
				sb.append(payLoad);
			}
			String finalLog = logUtil.maskLog(sb.toString());
			e2eTxn.logMessage("2984", finalLog);
			log.info(finalLog);
			e2eTxn.endInboundCall();
			BptmContextHolder.clearContext();
		}
	}

	private String getPayload(final HttpServletResponse response) {
		String responseBody = null;
		if (response instanceof ContentCachingResponseWrapper) {
			final ContentCachingResponseWrapper res = (ContentCachingResponseWrapper) response;
			try {
				responseBody = IOUtils.toString(res.getContentInputStream(), response.getCharacterEncoding());
				res.copyBodyToResponse();
			} catch (IOException e) {
				log.error(e.toString());
			}
		}
		return responseBody;
	}

	private String getPayload(final HttpServletRequest request) throws IOException {
		if (request instanceof ResettableRequestServletWrapper) {
			final ResettableRequestServletWrapper resettableRequest = (ResettableRequestServletWrapper) request;
			final String requestBody = IOUtils.toString(resettableRequest.getReader());

			resettableRequest.resetInputStream();
			return requestBody.substring(0, Math.min(1024, requestBody.length())); // only log the first 1kB
		} else {
			return "[unknown]";
		}
	}
}
