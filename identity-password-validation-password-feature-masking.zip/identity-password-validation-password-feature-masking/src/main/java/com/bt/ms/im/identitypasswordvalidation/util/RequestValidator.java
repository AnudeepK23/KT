/** */
package com.bt.ms.im.identitypasswordvalidation.util;

import com.bt.ms.im.exception.StandardError;
import com.bt.ms.im.exception.handler.standardexception.BadRequestException;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.service.SpringApplicationContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RequestValidator {

	@Autowired
	AppConstants appConstants;

	private static final Logger log = LoggerFactory.getLogger(RequestValidator.class);

	public void validateGetPasswordLengthRequest(GetPasswordLengthRequest request) {

		String brand = request.getBrand();
		String type = request.getType();
		
		if ((!(brand.equals(appConstants.getIdentityPasswordValidation().getBtcBrand())))
				&& (!(brand.equals(appConstants.getIdentityPasswordValidation().getEeBrand())))) {
			StandardError errormsg = StandardError.ERR400_28;
			log.error(errormsg.getMessage());
			throw new BadRequestException(errormsg);
		}

		if ((!(type.equals(appConstants.getIdentityPasswordValidation().getBtcType())))
				&& (!(type.equals(appConstants.getIdentityPasswordValidation().getEeGETType())))) {
			StandardError errormsg = StandardError.ERR400_28;
			log.error(errormsg.getMessage());
			throw new BadRequestException(errormsg);
		}

	}

	public void validateValidatePasswordRequest(ValidatePasswordRequest request) {
		String brand = request.getBrand();
		String type = request.getType();
		String char1 = request.getChar1();
		String char2 = request.getChar2();
		String pos1 = request.getPosition1();
		String pos2 = request.getPosition2();

		if (char1 == null || char2 == null || pos1 == null || pos2 == null) {
			StandardError errormsg = StandardError.ERR400_23;
			log.error(errormsg.getMessage());
			throw new BadRequestException(errormsg);
		}

		if ((!(brand.equals(appConstants.getIdentityPasswordValidation().getBtcBrand())))
				&& (!(brand.equals(appConstants.getIdentityPasswordValidation().getEeBrand())))) {
			StandardError errormsg = StandardError.ERR400_28;
			log.error(errormsg.getMessage());
			throw new BadRequestException(errormsg);
		}
		
		if ((!(type.equals(appConstants.getIdentityPasswordValidation().getBtcType())))
				&& (!(type.equals(appConstants.getIdentityPasswordValidation().getEePUTType())))) {
			StandardError errormsg = StandardError.ERR400_28;
			log.error(errormsg.getMessage());
			throw new BadRequestException(errormsg);
		}

	}

	public static AppConstants getAppConstant() {
		return SpringApplicationContextHolder.getBean(AppConstants.class);
	}

}
