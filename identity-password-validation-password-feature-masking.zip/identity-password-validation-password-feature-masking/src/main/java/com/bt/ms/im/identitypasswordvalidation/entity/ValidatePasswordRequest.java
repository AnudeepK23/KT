package com.bt.ms.im.identitypasswordvalidation.entity;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidatePasswordRequest {
	
	private String trackingHeader;
	private String e2eData;
	private String custId;
	private String acceptHeader;
	private String brand;
	private String type;
	private String char1;
	private String position1;
	private String char2;
	private String position2;
}
