package com.bt.ms.im.identitypasswordvalidation.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.ExcaliburValidatePasswordClient;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordRequest;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.ExcaliburGetSubscriberAuthenticationDetailsClient;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsRequest;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse.Message;

@SpringBootTest
@ActiveProfiles("test")
class ExcaliburRepositoryImplTest {

	@Autowired
	ExcaliburRepositoryImpl excaliburRepositoryImpl;

	@Mock
	ExcaliburGetSubscriberAuthenticationDetailsClient excaliburGetSubscriberAuthenticationDetailsClient;

	@Mock
	ExcaliburValidatePasswordClient excaliburValidatePasswordClient;

	@Test
	void triggerGetPasswordLengthSuccessTest() {
		GetPasswordLengthRequest getPasswordLengthRequest = new GetPasswordLengthRequest();
		getPasswordLengthRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		getPasswordLengthRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		getPasswordLengthRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		getPasswordLengthRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		getPasswordLengthRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		getPasswordLengthRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);

		GetSubscriberAuthenticationDetailsResponse getSubscriberAuthenticationDetailsResponse = new GetSubscriberAuthenticationDetailsResponse();
		Message message = new Message();
		message.setPasswordLength("12");
		getSubscriberAuthenticationDetailsResponse.setMessage(message);

		GetSubscriberAuthenticationDetailsRequest getSubscriberAuthenticationDetailsRequest = new GetSubscriberAuthenticationDetailsRequest();

		Mockito.when(excaliburGetSubscriberAuthenticationDetailsClient.getsubscriber(Mockito.any()))
				.thenReturn(getSubscriberAuthenticationDetailsResponse);
		assertNotNull(excaliburRepositoryImpl.getSubscriberAuthenticationDetails(getPasswordLengthRequest));

	}

	public void validatePasswordRepoSuccessTest() {
		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_EE);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_EE);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);

		ValidateAuthenticationPasswordResponse validateAuthenticationPasswordResponse = new ValidateAuthenticationPasswordResponse();

		validateAuthenticationPasswordResponse.setMessage("Success");

		Mockito.when(excaliburValidatePasswordClient.Validationpassword(Mockito.any()))
				.thenReturn(validateAuthenticationPasswordResponse);
		assertNotNull(excaliburRepositoryImpl.validateAuthenticationPassword(validatePasswordRequest));

	}

}
