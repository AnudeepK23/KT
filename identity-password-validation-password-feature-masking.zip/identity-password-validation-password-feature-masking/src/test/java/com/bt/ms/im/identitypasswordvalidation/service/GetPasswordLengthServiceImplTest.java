package com.bt.ms.im.identitypasswordvalidation.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.Password;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean.ResponseStatus;
import com.bt.ms.im.identitypasswordvalidation.entity.RootExceptionDetails;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.mapper.GetPasswordLengthResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepository;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepository;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.util.ExcaliburGetSubscriberUtil;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse.Message;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class GetPasswordLengthServiceImplTest {

	@InjectMocks
	GetPasswordLengthServiceImpl getPasswordLengthServiceImpl;

	@Mock
	ESBRepository esbrepo;

	@Mock
	private ESBRepositoryImpl eSBRepositoryImpl;

	@Mock
	private ExcaliburRepositoryImpl excaliburRepositoryImpl;

	@Mock
	ExcaliburRepository excrepo;

	@Mock
	CustomerValidationResponse customerValidationResponse;

	@Mock
	AppConstants appConstantsMock;

	@Autowired
	AppConstants appConstants;

	@Mock
	GetPasswordLengthResponseMapper getPasswordLengthResponseMapper;
	
	@Mock
	ExcaliburGetSubscriberUtil excaliburUtil;

	@Test
	void getPasswordLengthServiceTestForSuccess() {
		GetPasswordLengthRequest getPasswordLengthRequest = new GetPasswordLengthRequest();
		getPasswordLengthRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		getPasswordLengthRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		getPasswordLengthRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		getPasswordLengthRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		getPasswordLengthRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		getPasswordLengthRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);

		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());
		CustomerValidationResponse customerValidationResponse = new CustomerValidationResponse();
		customerValidationResponse.setCode(IdentityValidationTestConstants.SUCCESS_CODE);
		customerValidationResponse.setMessage(IdentityValidationTestConstants.SUCCESS_MESSAGE);
		ResponseBean<CustomerValidationResponse> customerValidationResponseBean = new ResponseBean<CustomerValidationResponse>();

		Mockito.when(esbrepo.queryCustomerForValidation(getPasswordLengthRequest))
				.thenReturn(ResponseBean.of(customerValidationResponse));

		ResponseBean<?> response = esbrepo.queryCustomerForValidation(getPasswordLengthRequest);
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();

		Password password = new Password();
		password.setPasswordLength("12");
		getPasswordLengthResponse.setPassword(password);
		Mockito.when(getPasswordLengthResponseMapper.mapperEsb(customerValidationResponseBean))
				.thenReturn(getPasswordLengthResponse);

		ResponseBean<?> resp = getPasswordLengthServiceImpl.getPasswordLength(getPasswordLengthRequest);
		Assertions.assertAll("resp", () -> Assertions.assertEquals(ResponseStatus.SUCCESS, resp.getStatus()));

	}

	@Test
	void getPasswordLengthServiceTest2ForSuccess() {

		GetPasswordLengthRequest getPasswordLengthRequest = new GetPasswordLengthRequest();
		getPasswordLengthRequest.setBrand(IdentityValidationTestConstants.BRAND_EE);
		getPasswordLengthRequest.setType(IdentityValidationTestConstants.TYPE_EE);
		getPasswordLengthRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		getPasswordLengthRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		getPasswordLengthRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		getPasswordLengthRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);

		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());
		GetSubscriberAuthenticationDetailsResponse getSubscriberAuthenticationDetailsResponse = new GetSubscriberAuthenticationDetailsResponse();
		ResponseBean<GetSubscriberAuthenticationDetailsResponse> getSubscriberAuthenticationDetailsResponseBean = new ResponseBean<GetSubscriberAuthenticationDetailsResponse>();
		Message message = new Message();
		message.setPasswordLength("9");

		getSubscriberAuthenticationDetailsResponse.setMessage(message);

		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();

		Mockito.when(excrepo.getSubscriberAuthenticationDetails(getPasswordLengthRequest))
				.thenReturn(ResponseBean.of(getSubscriberAuthenticationDetailsResponse));

		ResponseBean<?> response = excrepo.getSubscriberAuthenticationDetails(getPasswordLengthRequest);

		Mockito.when(getPasswordLengthResponseMapper.mapperExcalibur(getSubscriberAuthenticationDetailsResponseBean))
				.thenReturn(getPasswordLengthResponse);

		ResponseBean<?> resp = getPasswordLengthServiceImpl.getPasswordLength(getPasswordLengthRequest);
		Assertions.assertAll("resp", () -> Assertions.assertEquals(ResponseStatus.SUCCESS, resp.getStatus()));
	}

	@Test
	void getPasswordLengthServiceTest2ForFailure() {

		GetPasswordLengthRequest getPasswordLengthRequest = new GetPasswordLengthRequest();
		getPasswordLengthRequest.setBrand(IdentityValidationTestConstants.BRAND_EE);
		getPasswordLengthRequest.setType(IdentityValidationTestConstants.TYPE_EE);
		getPasswordLengthRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		getPasswordLengthRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		getPasswordLengthRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		getPasswordLengthRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);

		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
		.thenReturn(appConstants.getIdentityPasswordValidation());

		ResponseBean<GetSubscriberAuthenticationDetailsResponse> response = this.excErrorConstruct1("60", "Resource Not Found",
				"MSISDN_NOT_FOUND", "MSISDN is not Found");
		Mockito.when(excrepo.getSubscriberAuthenticationDetails(getPasswordLengthRequest))
		.thenReturn(response);
		
		ResponseBean<?> response3 = excrepo.getSubscriberAuthenticationDetails(getPasswordLengthRequest);

		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();

		ResponseBean<?> resp = getPasswordLengthServiceImpl.getPasswordLength(getPasswordLengthRequest);
		assertEquals("FAILURE", response3.getStatus().toString());

			
	
	}

	@SuppressWarnings("unchecked")
	public ResponseBean<GetSubscriberAuthenticationDetailsResponse> excErrorConstruct1(String clientErrorCode, String message,
			String reasonCode, String reasonText) {
		return ResponseBean.errorRes(clientErrorCode, message,
				RootExceptionDetails.of("BTSEL-EXC", reasonCode, reasonText));
	}

}
