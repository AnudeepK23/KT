
package com.bt.ms.im.identitypasswordvalidation.repository;

import org.springframework.http.HttpEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean.ResponseStatus;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;

@SpringBootTest
@ActiveProfiles("test")
class ESBRepositoryImplTest {

	@Autowired
	ESBRepositoryImpl eSBRepositoryImpl;

	@Mock
	RestTemplate restTemplate;

	@Test
	void triggerGetPasswordLengthTestWhenSuccess() {

		GetPasswordLengthRequest getPasswordLengthRequest = new GetPasswordLengthRequest();
		getPasswordLengthRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		getPasswordLengthRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		getPasswordLengthRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		getPasswordLengthRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		getPasswordLengthRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		getPasswordLengthRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);

		ResponseEntity<String> response = new ResponseEntity<String>(HttpStatus.OK);
		Mockito.when(
				restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.<Class<String>>any()))
				.thenReturn(response);
		assertNotNull(eSBRepositoryImpl.queryCustomerForValidation(getPasswordLengthRequest));

	}

	@Test
	void validatePasswordRepotestWhenSuccess() {
		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);

		ResponseEntity<String> response = new ResponseEntity<String>(HttpStatus.OK);
		Mockito.when(
				restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.<Class<String>>any()))
				.thenReturn(response);
		assertNotNull(eSBRepositoryImpl.validatePassword(validatePasswordRequest));
	}

}
