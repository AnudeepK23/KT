
package com.bt.ms.im.identitypasswordvalidation.controller;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.test.context.ActiveProfiles;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.GetPasswordLengthResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean.ResponseStatus;
import com.bt.ms.im.identitypasswordvalidation.service.GetPasswordLengthService;
import com.bt.ms.im.identitypasswordvalidation.service.ValidatePasswordStatusService;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.bt.ms.im.identitypasswordvalidation.util.RequestValidator;

@SpringBootTest
@ActiveProfiles("test")
 class IdentityValidationControllerTest {

	@Mock
	GetPasswordLengthService getPasswordLengthService;

	@Mock
	ValidatePasswordStatusService validatePasswordStatusService;

	@InjectMocks
	IdentityValidationController identityValidationController;

	@Mock
	private RequestValidator requestValidator;

	@Mock
	ValidatePasswordRequest validatePasswordRequest;

	@Mock
	AppConstants mockAppConstants;

	@Autowired
	AppConstants appConstants;

	@Test void getPasswordLengthResponseForBTWhenSuccess() {
  Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(
  any()); GetPasswordLengthResponse getPasswordLengthResponse = new
  GetPasswordLengthResponse();
  Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(
  GetPasswordLengthRequest.class)))
  .thenReturn(ResponseBean.of(getPasswordLengthResponse));
  ResponseEntity<GetPasswordLengthResponse> res =
  identityValidationController.getPasswordLength(
  IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
  IdentityValidationTestConstants.TRACKING_HEADER,
  IdentityValidationTestConstants.E2E_DATA,
  IdentityValidationTestConstants.ACCEPT_HEADER); Assertions.assertAll("res",
  () -> Assertions.assertEquals(HttpStatus.OK, res.getStatusCode())); }

	@Test
 void getPasswordLengthResponseForEEWhenSuccess() {
		Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(any());
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(GetPasswordLengthRequest.class)))
				.thenReturn(ResponseBean.of(getPasswordLengthResponse));
		ResponseEntity<GetPasswordLengthResponse> res = identityValidationController.getPasswordLength(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEeGETType(),
				IdentityValidationTestConstants.TRACKING_HEADER, IdentityValidationTestConstants.E2E_DATA,
				IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertAll("res", () -> Assertions.assertEquals(HttpStatus.OK, res.getStatusCode()));
	}

	@Test
 void validatePasswordServiceResponseForBTWhenSuccess() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(ResponseBean.of(validatePasswordResponse));

		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertAll("res", () -> Assertions.assertEquals(HttpStatus.OK, res.getStatusCode()));

	}

	@Test
 void validatePasswordServiceResponseForEEWhenSuccess() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(ResponseBean.of(validatePasswordResponse));
		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEePUTType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertAll("res", () -> Assertions.assertEquals(HttpStatus.OK, res.getStatusCode()));

	}

	@Test
	 void getPasswordLengthBusinessException503_Failure() throws Exception {
		Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(any());
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		ResponseBean<GetPasswordLengthResponse> response = ResponseBean.errorRes("05",
				"The service is temporarily unavailable", null);
		response.setStatus(ResponseStatus.FAILURE);

		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(GetPasswordLengthRequest.class)))
				.thenReturn(response);

		ResponseEntity<GetPasswordLengthResponse> res = identityValidationController.getPasswordLength(
				IdentityValidationTestConstants.CUSTOMER_ID,appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEeGETType(),
				IdentityValidationTestConstants.TRACKING_HEADER, IdentityValidationTestConstants.E2E_DATA,
				IdentityValidationTestConstants.ACCEPT_HEADER);

		Assertions.assertEquals(503, res.getStatusCode().value());

	}

	@Test
	 void getPasswordLengthBusinessException404_Failure() throws Exception {
		Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(any());
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		ResponseBean<GetPasswordLengthResponse> response = ResponseBean.errorRes("60", "Resource Not Found", null);
		response.setStatus(ResponseStatus.FAILURE);

		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(GetPasswordLengthRequest.class)))
				.thenReturn(response);

		ResponseEntity<GetPasswordLengthResponse> res = identityValidationController.getPasswordLength(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEePUTType(),
				IdentityValidationTestConstants.TRACKING_HEADER, IdentityValidationTestConstants.E2E_DATA,
				IdentityValidationTestConstants.ACCEPT_HEADER);

		Assertions.assertEquals(404, res.getStatusCode().value());

	}

	@Test
	 void getPasswordLengthBusinessException400_Failure() throws Exception {
		Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(any());
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		ResponseBean<GetPasswordLengthResponse> response = ResponseBean.errorRes("29", "Bad Request", null);
		response.setStatus(ResponseStatus.FAILURE);

		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(GetPasswordLengthRequest.class)))
				.thenReturn(response);

		ResponseEntity<GetPasswordLengthResponse> res = identityValidationController.getPasswordLength(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEeGETType(),
				IdentityValidationTestConstants.TRACKING_HEADER, IdentityValidationTestConstants.E2E_DATA,
				IdentityValidationTestConstants.ACCEPT_HEADER);

		Assertions.assertEquals(400, res.getStatusCode().value());

	}

	@Test
	 void getPasswordLengthBusinessException500_Failure() throws Exception {
		Mockito.doNothing().when(requestValidator).validateGetPasswordLengthRequest(any());
		GetPasswordLengthResponse getPasswordLengthResponse = new GetPasswordLengthResponse();
		ResponseBean<GetPasswordLengthResponse> response = ResponseBean.errorRes("02", "Internal Error", null);
		response.setStatus(ResponseStatus.FAILURE);

		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(getPasswordLengthService.getPasswordLength(Mockito.any(GetPasswordLengthRequest.class)))
				.thenReturn(response);

		ResponseEntity<GetPasswordLengthResponse> res = identityValidationController.getPasswordLength(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getEeBrand(), appConstants.getIdentityPasswordValidation().getEePUTType(),
				IdentityValidationTestConstants.TRACKING_HEADER, IdentityValidationTestConstants.E2E_DATA,
				IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertEquals(500, res.getStatusCode().value());

	}

	@Test
	 void validatePasswordService503_Failure() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		ResponseBean<ValidatePasswordResponse> response = ResponseBean.errorRes("05",
				"The service is temporarily unavailable", null);
		response.setStatus(ResponseStatus.FAILURE);
		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(response);

		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertEquals(503, res.getStatusCode().value());

	}

	@Test
	 void validatePasswordService404_Failure() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		ResponseBean<ValidatePasswordResponse> response = ResponseBean.errorRes("60", "Resource Not Found", null);
		response.setStatus(ResponseStatus.FAILURE);
		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(response);

		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertEquals(404, res.getStatusCode().value());

	}

	@Test
	 void validatePasswordService400_Failure() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		ResponseBean<ValidatePasswordResponse> response = ResponseBean.errorRes("29", "Bad Request", null);
		response.setStatus(ResponseStatus.FAILURE);
		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(response);

		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertEquals(400, res.getStatusCode().value());

	}

	@Test
	 void validatePasswordService500_Failure() {
		Mockito.doNothing().when(requestValidator).validateValidatePasswordRequest(any());
		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		ResponseBean<ValidatePasswordResponse> response = ResponseBean.errorRes("02", "Internal Error", null);
		response.setStatus(ResponseStatus.FAILURE);
		Mockito.when(mockAppConstants.getErrorRes()).thenReturn(appConstants.getErrorRes());
		Mockito.when(
				validatePasswordStatusService.validatePasswordStatus(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(response);

		ResponseEntity<ValidatePasswordResponse> res = identityValidationController.validatePasswordStatus(
				IdentityValidationTestConstants.CUSTOMER_ID, appConstants.getIdentityPasswordValidation().getBtcBrand(), appConstants.getIdentityPasswordValidation().getBtcType(),
				validatePasswordRequest, IdentityValidationTestConstants.TRACKING_HEADER,
				IdentityValidationTestConstants.E2E_DATA, IdentityValidationTestConstants.ACCEPT_HEADER);
		Assertions.assertEquals(500, res.getStatusCode().value());

	}

}
