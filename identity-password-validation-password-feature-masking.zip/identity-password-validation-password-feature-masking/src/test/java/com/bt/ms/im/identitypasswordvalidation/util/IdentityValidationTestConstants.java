package com.bt.ms.im.identitypasswordvalidation.util;

public class IdentityValidationTestConstants {

	public static final String TRACKING_HEADER = "3f712305-5181-42b2-b4e9-e44f22c01696";
	  public static final String SOURCE = "common";
      public static final String SAMPLE_URL = "http://localhost/testesb";
	  
	  public static final String CUSTOMER_ID = "123";
	  
	  public static final String BRAND_EE = "EE";
	  public static final String BRAND_BT = "BTC";
	  public static final String TYPE_EE = "MSISDN";
	  public static final String TYPE_BT = "account";
	  public static final String E2E_DATA = "abcd";
	  public static final String ACCEPT_HEADER = "application/json";
	  public static final String SUCCESS_STATUS = "Success";
	  public static final String FAILURE_STATUS = "Fail";
	  
	  public static final String CHAR1 = "b";
	  public static final String CHAR2 = "d";
	  public static final String POSITION1 = "1";
	  public static final String POSITION2 = "2";


	  public static final String SUCCESS_MESSAGE = "SUCCESS";
	  public static final String ERROR_MESSAGE = "ERROR";

	  public static final String SUCCESS_CODE = "200";
	  public static final String ERROR_CODE = "02";
	
	
}
