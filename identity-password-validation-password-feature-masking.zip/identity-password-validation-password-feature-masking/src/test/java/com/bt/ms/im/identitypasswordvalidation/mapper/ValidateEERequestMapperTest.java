package com.bt.ms.im.identitypasswordvalidation.mapper;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;

@SpringBootTest
@ActiveProfiles("test")
class ValidateEERequestMapperTest {
	
	@InjectMocks
	ValidateEERequestMapper validateEERequestMapper;
	
	@Mock
	AppConstants appConstantsMock;

	@Autowired
	AppConstants appConstants;
	
	@Test
	void validateBTCRequestForSuccess()
	{
		Mockito.when(appConstantsMock.getIdentityPasswordValidation()).thenReturn(appConstants.getIdentityPasswordValidation());
		Mockito.when(appConstantsMock.getValidateCustomerPassword()).thenReturn(appConstants.getValidateCustomerPassword());
		
		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();
		validatePasswordRequest.setChar1("a");
		validatePasswordRequest.setChar2("b");
		validatePasswordRequest.setPosition1("1");
		validatePasswordRequest.setPosition2("2");
		validatePasswordRequest.setCustId("123");
		
		assertNotNull(validateEERequestMapper.validateBTCRequest(validatePasswordRequest));
		
	}

}
