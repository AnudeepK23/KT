
package com.bt.ms.im.identitypasswordvalidation.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import com.bt.ms.im.identitypasswordvalidation.IdentityValidationApplication;
import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.RootExceptionDetails;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordRequest;
import com.bt.ms.im.identitypasswordvalidation.entity.ValidatePasswordResponse;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean.ResponseStatus;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;
import com.bt.ms.im.identitypasswordvalidation.mapper.ValidatePasswordResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.repository.ESBRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.repository.ExcaliburRepositoryImpl;
import com.bt.ms.im.identitypasswordvalidation.util.ExcaliburValidatePasswordUtil;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

@ContextConfiguration(classes = { IdentityValidationApplication.class, AppConstants.class })

@ActiveProfiles("test")
class ValidatePasswordStatusServiceImplTest {

	@InjectMocks
	ValidatePasswordStatusServiceImpl ValidatePasswordStatusServiceImpl;

	@Mock
	private ESBRepositoryImpl eSBRepositoryImpl;

	@Mock
	private ExcaliburRepositoryImpl excaliburRepositoryImpl;

	@Mock
	AppConstants appConstantsMock;

	@Autowired
	AppConstants appConstants;

	@Mock
	ValidatePasswordResponseMapper mapper;
	
	@Mock
	ExcaliburValidatePasswordUtil excaliburValidatePasswordUtil;

	@Test
	void validatePasswordStatusserviceTest() {

		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();

		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);

		Mockito.when(appConstantsMock.getValidateCustomerPassword())
				.thenReturn(appConstants.getValidateCustomerPassword());
		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());

		ValidateCustomerPassword validateCustomerPassword = new ValidateCustomerPassword();
		validateCustomerPassword.setCode(IdentityValidationTestConstants.SUCCESS_CODE);
		validateCustomerPassword.setMessage(IdentityValidationTestConstants.SUCCESS_MESSAGE);

		Mockito.when(eSBRepositoryImpl.validatePassword(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(ResponseBean.of(validateCustomerPassword));

		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();

		validatePasswordResponse.setMessage("Valid");

		Mockito.when(mapper.mapperEsb(Mockito.any())).thenReturn(validatePasswordResponse);

		ResponseBean<?> resp = ValidatePasswordStatusServiceImpl.validatePasswordStatus(validatePasswordRequest);
		Assertions.assertAll("resp", () -> Assertions.assertEquals(ResponseStatus.SUCCESS, resp.getStatus()));

	}

	@Test
	void validatePasswordStatusserviceTest2() {

		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();

		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_EE);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_EE);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);

		Mockito.when(appConstantsMock.getValidateCustomerPassword())
				.thenReturn(appConstants.getValidateCustomerPassword());
		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());

		ValidateAuthenticationPasswordResponse validateAuthenticationPasswordResponse = new ValidateAuthenticationPasswordResponse();

		validateAuthenticationPasswordResponse.setMessage("Valid");

		Mockito.when(excaliburRepositoryImpl.validateAuthenticationPassword(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(ResponseBean.of(validateAuthenticationPasswordResponse));

		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();
		validatePasswordResponse.setMessage("Valid");

		Mockito.when(mapper.mapperExcalibur(Mockito.any())).thenReturn(validatePasswordResponse);

		ResponseBean<?> resp = ValidatePasswordStatusServiceImpl.validatePasswordStatus(validatePasswordRequest);
		Assertions.assertAll("resp", () -> Assertions.assertEquals(ResponseStatus.SUCCESS, resp.getStatus()));

	}

	@Test
	void validatePasswordStatusserviceTestForFailure() {

		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();

		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_BT);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_BT);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);

		Mockito.when(appConstantsMock.getValidateCustomerPassword())
				.thenReturn(appConstants.getValidateCustomerPassword());
		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());

		ResponseBean<ValidateCustomerPassword> validateCustomerPassword = new ResponseBean<ValidateCustomerPassword>();
		validateCustomerPassword.setCode(IdentityValidationTestConstants.ERROR_CODE);
		validateCustomerPassword.setMessage(IdentityValidationTestConstants.ERROR_MESSAGE);
		validateCustomerPassword.setStatus(ResponseStatus.FAILURE);

		Mockito.when(eSBRepositoryImpl.validatePassword(Mockito.any(ValidatePasswordRequest.class)))
				.thenReturn(ResponseBean.errorRes(ValidateCustomerPassword.class, validateCustomerPassword));

		ValidatePasswordResponse validatePasswordResponse = new ValidatePasswordResponse();

		validatePasswordResponse.setMessage("Valid");

		Mockito.when(mapper.mapperEsb(Mockito.any())).thenReturn(validatePasswordResponse);

		ResponseBean<?> resp = ValidatePasswordStatusServiceImpl.validatePasswordStatus(validatePasswordRequest);
		Assertions.assertAll("resp", () -> Assertions.assertEquals(ResponseStatus.FAILURE, resp.getStatus()));

	}
	
	@Test
	void validatePasswordStatusserviceTest2ForFailure() {

		ValidatePasswordRequest validatePasswordRequest = new ValidatePasswordRequest();

		validatePasswordRequest.setBrand(IdentityValidationTestConstants.BRAND_EE);
		validatePasswordRequest.setType(IdentityValidationTestConstants.TYPE_EE);
		validatePasswordRequest.setCustId(IdentityValidationTestConstants.CUSTOMER_ID);
		validatePasswordRequest.setTrackingHeader(IdentityValidationTestConstants.TRACKING_HEADER);
		validatePasswordRequest.setE2eData(IdentityValidationTestConstants.E2E_DATA);
		validatePasswordRequest.setAcceptHeader(IdentityValidationTestConstants.ACCEPT_HEADER);
		validatePasswordRequest.setChar1(IdentityValidationTestConstants.CHAR1);
		validatePasswordRequest.setChar2(IdentityValidationTestConstants.CHAR2);
		validatePasswordRequest.setPosition1(IdentityValidationTestConstants.POSITION1);
		validatePasswordRequest.setPosition2(IdentityValidationTestConstants.POSITION2);

		Mockito.when(appConstantsMock.getValidateCustomerPassword())
				.thenReturn(appConstants.getValidateCustomerPassword());
		Mockito.when(appConstantsMock.getIdentityPasswordValidation())
				.thenReturn(appConstants.getIdentityPasswordValidation());

		ResponseBean<ValidateAuthenticationPasswordResponse> response = this.excErrorConstruct1("60", "Resource Not Found",
				"MSISDN_NOT_FOUND", "MSISDN is not Found");
		Mockito.when(excaliburRepositoryImpl.validateAuthenticationPassword(Mockito.any(ValidatePasswordRequest.class)))
		.thenReturn(response);
		
		ResponseBean<?> response3 = excaliburRepositoryImpl.validateAuthenticationPassword(validatePasswordRequest);

		ResponseBean<?> resp = ValidatePasswordStatusServiceImpl.validatePasswordStatus(validatePasswordRequest);
		assertEquals("FAILURE", response3.getStatus().toString());
			
	
	}

	@SuppressWarnings("unchecked")
	public ResponseBean<ValidateAuthenticationPasswordResponse> excErrorConstruct1(String clientErrorCode, String message,
			String reasonCode, String reasonText) {
		return ResponseBean.errorRes(clientErrorCode, message,
				RootExceptionDetails.of("BTSEL-EXC", reasonCode, reasonText));
	}

}
