
package com.bt.ms.im.identitypasswordvalidation.mapper;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigInteger;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean;
import com.bt.ms.im.identitypasswordvalidation.entity.ResponseBean.ResponseStatus;
import com.bt.ms.im.identitypasswordvalidation.entity.esbquery.CustomerValidationResponse;
import com.bt.ms.im.identitypasswordvalidation.mapper.GetPasswordLengthResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse;
import com.ee.ms.im.excalibur.subscriber.getSubscriberAuthenticationDetails.wsdl.GetSubscriberAuthenticationDetailsResponse.Message;

@SpringBootTest
@ActiveProfiles("test")
class GetPasswordLengthResponseMapperTest {

	@InjectMocks
	GetPasswordLengthResponseMapper getPasswordLengthResponseMapper;

	@Test
	void mapperEsbTest() {

		CustomerValidationResponse customerValidationResponse = new CustomerValidationResponse();
		ResponseBean<CustomerValidationResponse> customerValidationresponse = new ResponseBean<CustomerValidationResponse>();
		customerValidationresponse.setStatus(ResponseStatus.SUCCESS);
		
		CustomerValidationResponse.Customer customer = new CustomerValidationResponse.Customer();
		BigInteger t = BigInteger.valueOf(23);
		customer.setPasswordLength(t);
		customerValidationResponse.setCustomer(customer);
		customerValidationresponse.setData(customerValidationResponse);
		assertNotNull(getPasswordLengthResponseMapper.mapperEsb(customerValidationresponse));

	}
	
	@Test
	void mapperEsbTestFailure() {

		CustomerValidationResponse customerValidationResponse = new CustomerValidationResponse();
		ResponseBean<CustomerValidationResponse> customerValidationresponse = new ResponseBean<CustomerValidationResponse>();
		customerValidationresponse.setStatus(ResponseStatus.FAILURE);
		
		CustomerValidationResponse.Customer customer = new CustomerValidationResponse.Customer();
		BigInteger t = BigInteger.valueOf(23);
		customer.setPasswordLength(t);
		customerValidationResponse.setCustomer(customer);
		customerValidationresponse.setData(customerValidationResponse);
		assertNotNull(getPasswordLengthResponseMapper.mapperEsb(customerValidationresponse));

	}

	@Test
	void mapperExcaliburTest() {

		GetSubscriberAuthenticationDetailsResponse getSubscriberAuthenticationDetailsResponse = new GetSubscriberAuthenticationDetailsResponse();
		ResponseBean<GetSubscriberAuthenticationDetailsResponse> getSubscriberAuthenticationDetailsresponse = new ResponseBean<GetSubscriberAuthenticationDetailsResponse>();
		getSubscriberAuthenticationDetailsresponse.setStatus(ResponseStatus.SUCCESS);
		Message message = new Message();
		message.setPasswordLength("12");
		getSubscriberAuthenticationDetailsResponse.setMessage(message);
		getSubscriberAuthenticationDetailsresponse.setData(getSubscriberAuthenticationDetailsResponse);
		assertNotNull(getPasswordLengthResponseMapper.mapperExcalibur(getSubscriberAuthenticationDetailsresponse));

	}
	
	@Test
	void mapperExcaliburTestFailure() {

		GetSubscriberAuthenticationDetailsResponse getSubscriberAuthenticationDetailsResponse = new GetSubscriberAuthenticationDetailsResponse();
		ResponseBean<GetSubscriberAuthenticationDetailsResponse> getSubscriberAuthenticationDetailsresponse = new ResponseBean<GetSubscriberAuthenticationDetailsResponse>();
		getSubscriberAuthenticationDetailsresponse.setStatus(ResponseStatus.FAILURE);
		Message message = new Message();
		message.setPasswordLength("12");
		getSubscriberAuthenticationDetailsResponse.setMessage(message);

		assertNotNull(getPasswordLengthResponseMapper.mapperExcalibur(getSubscriberAuthenticationDetailsresponse));

	}

}
