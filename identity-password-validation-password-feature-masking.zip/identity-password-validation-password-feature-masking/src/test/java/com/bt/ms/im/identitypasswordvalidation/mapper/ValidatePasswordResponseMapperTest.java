package com.bt.ms.im.identitypasswordvalidation.mapper;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.bt.ms.im.identitypasswordvalidation.config.AppConstants;
import com.bt.ms.im.identitypasswordvalidation.entity.esbvalidate.ValidateCustomerPassword;
import com.bt.ms.im.identitypasswordvalidation.mapper.ValidatePasswordResponseMapper;
import com.bt.ms.im.identitypasswordvalidation.util.IdentityValidationTestConstants;
import com.ee.ms.im.excalibur.account.validateauthenticationpassword.wsdl.ValidateAuthenticationPasswordResponse;

@SpringBootTest
@ActiveProfiles("test")
class ValidatePasswordResponseMapperTest {

	@Autowired
	ValidatePasswordResponseMapper validatePasswordResponseMapper;

	@Mock
	AppConstants appConstantsMock;

	@Autowired
	AppConstants appConstants;

	@Test
	void mapperEsbTestForSuccessStatus() {

		ValidateCustomerPassword validateCustomerPassword = new ValidateCustomerPassword();
		validateCustomerPassword.setStatus(IdentityValidationTestConstants.SUCCESS_STATUS);

		// Mockito.when(appConstantsMock.getValidateCustomerPassword().getSuccessStatus()).thenReturn(appConstants.getValidateCustomerPassword().getSuccessStatus());
		// Mockito.when(appConstantsMock.getValidateCustomerPassword().getFailureStatus()).thenReturn(appConstants.getValidateCustomerPassword().getFailureStatus());

		assertNotNull(validatePasswordResponseMapper.mapperEsb(validateCustomerPassword));

	}

	@Test
	void mapperEsbTestForFailureStatus() {
		ValidateCustomerPassword validateCustomerPassword = new ValidateCustomerPassword();
		validateCustomerPassword.setStatus(IdentityValidationTestConstants.FAILURE_STATUS);

		assertNotNull(validatePasswordResponseMapper.mapperEsb(validateCustomerPassword));

	}

	@Test
	void mapperExcaliburTestForSuccessStatus() {

		ValidateAuthenticationPasswordResponse validateAuthenticationPasswordResponse = new ValidateAuthenticationPasswordResponse();
		validateAuthenticationPasswordResponse.setMessage(IdentityValidationTestConstants.SUCCESS_STATUS);

		assertNotNull(validatePasswordResponseMapper.mapperExcalibur(validateAuthenticationPasswordResponse));

	}

	@Test
	void mapperExcaliburTestForFailureStatus() {

		ValidateAuthenticationPasswordResponse validateAuthenticationPasswordResponse = new ValidateAuthenticationPasswordResponse();
		validateAuthenticationPasswordResponse.setMessage(IdentityValidationTestConstants.FAILURE_STATUS);

		assertNotNull(validatePasswordResponseMapper.mapperExcalibur(validateAuthenticationPasswordResponse));

	}

}
